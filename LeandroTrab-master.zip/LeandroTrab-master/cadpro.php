﻿<?php
session_start();

$erro_id = "";
$erro_nome = "";
$erro_descricao = "";
$erro_marca = "";
$erro_preco = "";
$erro_estoque = "";
$erro_detalhes = "";

$erro_validacao = 0;

if (isset($_POST["botao"])) {
    $_SESSION["id_produto"] = $_POST["id_produto"];
    $_SESSION["nome_produto"] = $_POST["nome_produto"];
    $_SESSION["descricao"] = $_POST["descricao"];
    $_SESSION["marca"] = $_POST["marca"];
    $_SESSION["preco"] = $_POST["preco"];
    $_SESSION["estoque"] = $_POST["estoque"];
    $_SESSION["detalhes"] = $_POST["detalhes"];

    $id_produto = $_SESSION["id_produto"];
    $nome_produto = $_SESSION["nome_produto"];
    $descricao = $_SESSION["descricao"];
    $marca = $_SESSION["marca"];
    $preco = $_SESSION["preco"];
    $estoque = $_SESSION["estoque"];
    $detalhes = $_SESSION["detalhes"];

    if (trim($id_produto) === "") {
        $erro_id = "<span style='color: red;'>Preencha o ID do produto</span>";
        $erro_validacao++;
    }

    if (trim($nome_produto) === "") {
        $erro_nome = "<span style='color: red;'>Preencha o nome do produto</span>";
        $erro_validacao++;
    }

    if (trim($descricao) === "") {
        $erro_descricao = "<span style='color: red;'>Preencha a descrição</span>";
        $erro_validacao++;
    }

    if (trim($marca) === "") {
        $erro_marca = "<span style='color: red;'>Preencha a marca/fabricante</span>";
        $erro_validacao++;
    }

    if (!is_numeric($preco) || floatval($preco) <= 0) {
        $erro_preco = "<span style='color: red;'>Informe um preço válido (número maior que 0)</span>";
        $erro_validacao++;
    }

    if (!ctype_digit($estoque) || intval($estoque) < 0) {
        $erro_estoque = "<span style='color: red;'>Informe uma quantidade válida (número inteiro maior ou igual a 0)</span>";
        $erro_validacao++;
    }

    if (trim($detalhes) === "") {
        $erro_detalhes = "<span style='color: red;'>Preencha o campo de cor/tamanho/peso</span>";
        $erro_validacao++;
    }

    if ($erro_validacao === 0) {
        header("Location:cadvenda.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<body>
    <h2>Cadastro de Produto</h2>
    <form action="cadpro.php" method="post">
        ID do Produto:<br>
        <input type="text" name="id_produto" value="<?php if (isset($_SESSION["id_produto"])) echo $_SESSION["id_produto"]; ?>">
        <?php echo $erro_id; ?>
        <br><br>

        Nome do Produto:<br>
        <input type="text" name="nome_produto" value="<?php if (isset($_SESSION["nome_produto"])) echo $_SESSION["nome_produto"]; ?>">
        <?php echo $erro_nome; ?>
        <br><br>

        Descrição:<br>
        <textarea name="descricao" rows="4" cols="50"><?php if (isset($_SESSION["descricao"])) echo $_SESSION["descricao"]; ?></textarea>
        <?php echo $erro_descricao; ?>
        <br><br>

        Marca:<br>
        <input type="text" name="marca" value="<?php if (isset($_SESSION["marca"])) echo $_SESSION["marca"]; ?>">
        <?php echo $erro_marca; ?>
        <br><br>

        Preço:<br>
        <input type="text" name="preco" value="<?php if (isset($_SESSION["preco"])) echo $_SESSION["preco"]; ?>">
        <?php echo $erro_preco; ?>
        <br><br>

        Estoque:<br>
        <input type="text" name="estoque" value="<?php if (isset($_SESSION["estoque"])) echo $_SESSION["estoque"]; ?>">
        <?php echo $erro_estoque; ?>
        <br><br>

        Cor/Tamanho/Peso:<br>
        <input type="text" name="detalhes" value="<?php if (isset($_SESSION["detalhes"])) echo $_SESSION["detalhes"]; ?>">
        <?php echo $erro_detalhes; ?>
        <br><br>

        <input type="submit" name="botao" value="Cadastrar Produto">
    </form>
</body>
</html>